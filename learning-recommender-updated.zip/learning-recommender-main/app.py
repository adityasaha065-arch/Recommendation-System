import streamlit as st

st.set_page_config(
    page_title="EduPath | Education Advisor",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ==================== CUSTOM UI / CSS ====================

st.markdown("""
<style>
.stApp {
    background-color: #f4f7fc;
    color: #334155;
}

.main .block-container {
    padding-top: 2rem;
    padding-bottom: 3rem;
    max-width: 1250px;
}

.stApp h1, .stApp h2, .stApp h3, .stApp h4 {
    color: #172554 !important;
    font-weight: 700 !important;
}

[data-testid="stAppViewContainer"] .main p,
[data-testid="stAppViewContainer"] .main label,
[data-testid="stAppViewContainer"] .main li {
    color: #334155;
}

/* SIDEBAR */
[data-testid="stSidebar"] {
    background-color: #172554;
}

[data-testid="stSidebar"] h1,
[data-testid="stSidebar"] h2,
[data-testid="stSidebar"] h3,
[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] {
    color: #ffffff !important;
}

/* INPUT FIELDS */
.stTextInput input,
.stTextArea textarea {
    background-color: #ffffff !important;
    color: #1e293b !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 10px !important;
    caret-color: #1e293b !important;
}

.stTextInput input::placeholder,
.stTextArea textarea::placeholder {
    color: #94a3b8 !important;
    opacity: 1 !important;
}

/* DROPDOWN */
.stSelectbox [data-baseweb="select"] > div {
    background-color: #ffffff !important;
    color: #1e293b !important;
}

.stSelectbox [data-baseweb="select"] *,
.stSelectbox [data-baseweb="select"] input {
    color: #1e293b !important;
    -webkit-text-fill-color: #1e293b !important;
}

[data-baseweb="popover"],
[data-baseweb="menu"],
[data-baseweb="menu"] li {
    background-color: #ffffff !important;
    color: #1e293b !important;
}

[data-baseweb="menu"] * {
    color: #1e293b !important;
}

/* FORM AND CARDS */
[data-testid="stForm"] {
    background-color: #ffffff;
    padding: 25px;
    border-radius: 16px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 4px 15px rgba(0,0,0,0.04);
}

[data-testid="stVerticalBlockBorderWrapper"] {
    background-color: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 15px;
}

[data-testid="stVerticalBlockBorderWrapper"] p,
[data-testid="stVerticalBlockBorderWrapper"] span {
    color: #334155 !important;
}

/* BUTTONS */
.stButton > button,
.stFormSubmitButton > button {
    background-color: #2563eb !important;
    color: #ffffff !important;
    border: none !important;
    border-radius: 10px !important;
    min-height: 45px;
    font-weight: 600;
}

.stButton > button *,
.stFormSubmitButton > button *,
.stButton > button p,
.stFormSubmitButton > button p {
    color: #ffffff !important;
    -webkit-text-fill-color: #ffffff !important;
}

.stButton > button:hover,
.stFormSubmitButton > button:hover {
    background-color: #1d4ed8 !important;
}

/* METRICS */
[data-testid="stMetric"] {
    background-color: #ffffff;
    padding: 18px;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
}

[data-testid="stMetric"] label,
[data-testid="stMetric"] [data-testid="stMetricValue"] {
    color: #172554 !important;
}

[data-testid="stAlert"] {
    border-radius: 12px;
}

hr {
    border-color: #e2e8f0;
}

.footer {
    text-align: center;
    color: #64748b !important;
    font-size: 13px;
    padding: 20px;
}
</style>
""", unsafe_allow_html=True)


# ==================== COURSE DATABASE ====================

COURSES = {

    "Computer Science & IT": {
        "topics": [
            "Python Programming",
            "Data Structures and Algorithms",
            "Database Management Systems",
            "Web Development",
            "Computer Networks",
            "Artificial Intelligence",
            "Machine Learning",
            "Cybersecurity",
            "Cloud Computing"
        ],

        "skills": [
            "Python", "Java", "SQL",
            "Problem Solving", "Git and GitHub",
            "Web Development"
        ],

        "class12": [
            "B.Tech Computer Science",
            "BCA",
            "B.Sc Computer Science",
            "B.Sc Information Technology"
        ],

        "diploma": [
            "B.Tech Computer Science (lateral entry, if eligible)",
            "BCA",
            "B.Sc Computer Science",
            "B.Sc Information Technology"
        ],

        "bachelor": [
            "MCA",
            "M.Sc Computer Science",
            "M.Sc Data Science",
            "M.Sc Artificial Intelligence",
            "M.Tech Computer Science (if eligible)"
        ],

        "master": [
            "Ph.D. in Computer Science",
            "Advanced Research in Artificial Intelligence",
            "Advanced Research in Data Science",
            "Specialized Cybersecurity Certifications"
        ],

        "careers": [
            "Software Developer",
            "Data Analyst",
            "Web Developer",
            "AI/ML Engineer",
            "Cybersecurity Analyst",
            "Cloud Engineer"
        ]
    },

    "Business & Management": {
        "topics": [
            "Business Communication",
            "Financial Accounting",
            "Marketing Management",
            "Human Resource Management",
            "Business Analytics",
            "Entrepreneurship",
            "Financial Management",
            "Business Strategy"
        ],

        "skills": [
            "Communication",
            "Leadership",
            "Excel",
            "Financial Analysis",
            "Digital Marketing",
            "Project Management"
        ],

        "class12": [
            "BBA",
            "B.Com",
            "Bachelor of Management Studies",
            "BA Economics"
        ],

        "diploma": [
            "BBA",
            "B.Com",
            "Bachelor of Management Studies"
        ],

        "bachelor": [
            "MBA",
            "M.Com",
            "MA Economics",
            "PG Diploma in Business Management",
            "Master's in Finance or Marketing"
        ],

        "master": [
            "Ph.D. in Management",
            "Ph.D. in Commerce",
            "Advanced Business Analytics",
            "Executive Management Programs"
        ],

        "careers": [
            "Business Analyst",
            "Marketing Manager",
            "Financial Analyst",
            "HR Manager",
            "Business Consultant",
            "Entrepreneur"
        ]
    },

    "Science & Research": {
        "topics": [
            "Scientific Research Methods",
            "Statistics",
            "Biotechnology",
            "Physics",
            "Chemistry",
            "Data Analysis",
            "Laboratory Techniques",
            "Research Writing"
        ],

        "skills": [
            "Research",
            "Scientific Writing",
            "Statistics",
            "Data Analysis",
            "Laboratory Skills",
            "Critical Thinking"
        ],

        "class12": [
            "B.Sc Physics",
            "B.Sc Chemistry",
            "B.Sc Mathematics",
            "B.Sc Biotechnology",
            "B.Sc Statistics"
        ],

        "diploma": [
            "B.Sc Applied Science",
            "B.Sc Biotechnology",
            "B.Sc Chemistry",
            "B.Sc Mathematics"
        ],

        "bachelor": [
            "M.Sc Physics",
            "M.Sc Chemistry",
            "M.Sc Mathematics",
            "M.Sc Biotechnology",
            "M.Sc Statistics"
        ],

        "master": [
            "Ph.D. in Science",
            "Research Fellowships",
            "Advanced Scientific Research Programs"
        ],

        "careers": [
            "Research Scientist",
            "Laboratory Analyst",
            "Research Assistant",
            "Data Scientist",
            "Science Educator"
        ]
    },

    "Arts & Humanities": {
        "topics": [
            "History",
            "Political Science",
            "Psychology",
            "Sociology",
            "English Literature",
            "Philosophy",
            "Creative Writing",
            "Communication"
        ],

        "skills": [
            "Writing",
            "Communication",
            "Critical Thinking",
            "Research",
            "Public Speaking",
            "Content Creation"
        ],

        "class12": [
            "BA English",
            "BA Psychology",
            "BA History",
            "BA Political Science",
            "BA Sociology"
        ],

        "diploma": [
            "BA English",
            "BA Psychology",
            "BA History",
            "BA Sociology"
        ],

        "bachelor": [
            "MA English",
            "MA Psychology",
            "MA History",
            "MA Political Science",
            "MA Sociology"
        ],

        "master": [
            "Ph.D. in Humanities",
            "Ph.D. in Psychology",
            "Advanced Research Programs"
        ],

        "careers": [
            "Psychologist (with required qualifications)",
            "Content Writer",
            "Journalist",
            "Teacher",
            "Researcher",
            "Social Worker"
        ]
    },

    "Engineering & Technology": {
        "topics": [
            "Engineering Mathematics",
            "Electrical Circuits",
            "Mechanical Design",
            "Computer-Aided Design",
            "Robotics",
            "Electronics",
            "Embedded Systems",
            "Renewable Energy"
        ],

        "skills": [
            "Problem Solving",
            "CAD Tools",
            "Programming",
            "Technical Drawing",
            "Robotics",
            "Project Design"
        ],

        "class12": [
            "B.Tech Mechanical Engineering",
            "B.Tech Electrical Engineering",
            "B.Tech Civil Engineering",
            "B.Tech Electronics Engineering"
        ],

        "diploma": [
            "B.Tech through lateral entry (if eligible)",
            "B.E. through lateral entry (if eligible)",
            "Specialized Engineering Certifications"
        ],

        "bachelor": [
            "M.Tech Mechanical Engineering",
            "M.Tech Electrical Engineering",
            "M.Tech Civil Engineering",
            "M.Tech Electronics Engineering"
        ],

        "master": [
            "Ph.D. in Engineering",
            "Advanced Robotics Research",
            "Advanced Engineering Research"
        ],

        "careers": [
            "Mechanical Engineer",
            "Electrical Engineer",
            "Civil Engineer",
            "Electronics Engineer",
            "Robotics Engineer"
        ]
    },

    "Healthcare & Biology": {
        "topics": [
            "Human Anatomy",
            "Human Physiology",
            "Microbiology",
            "Genetics",
            "Biochemistry",
            "Public Health",
            "Biotechnology",
            "Nutrition"
        ],

        "skills": [
            "Scientific Knowledge",
            "Laboratory Skills",
            "Research",
            "Communication",
            "Patient Care",
            "Data Analysis"
        ],

        "class12": [
            "B.Sc Nursing",
            "B.Sc Biotechnology",
            "B.Sc Microbiology",
            "B.Pharm",
            "Relevant Allied Health Programs"
        ],

        "diploma": [
            "B.Sc Nursing (if eligible)",
            "B.Pharm (if eligible)",
            "Relevant Allied Health Degree Programs"
        ],

        "bachelor": [
            "M.Sc Biotechnology",
            "M.Sc Microbiology",
            "M.Sc Biochemistry",
            "Master of Public Health",
            "M.Sc Nutrition"
        ],

        "master": [
            "Ph.D. in Biotechnology",
            "Ph.D. in Microbiology",
            "Ph.D. in Biomedical Science",
            "Advanced Public Health Research"
        ],

        "careers": [
            "Biotechnologist",
            "Microbiologist",
            "Research Assistant",
            "Public Health Professional",
            "Clinical Research Associate"
        ]
    }
}


# ==================== HELPER FUNCTIONS ====================

def get_level_key(qualification):

    mapping = {
        "Class 12": "class12",
        "Diploma": "diploma",
        "Bachelor's Degree": "bachelor",
        "Master's Degree": "master",
        "Other": "class12"
    }

    return mapping[qualification]


def recommend_courses(qualification, interest):

    return COURSES[interest][get_level_key(qualification)]


def recommend_next_topics(interest, studied_subjects):

    topics = COURSES[interest]["topics"]

    studied = studied_subjects.lower()

    return [
        topic for topic in topics
        if topic.lower() not in studied
    ][:6]


# ==================== SIDEBAR ====================

with st.sidebar:

    st.markdown("""
    <h1 style="color:white; text-align:center;">
        🎓 EduPath
    </h1>

    <p style="color:white; text-align:center;">
        Education & Career Advisor
    </p>
    """, unsafe_allow_html=True)

    st.divider()

    st.markdown("### 🧭 Navigation")

    page = st.radio(
        "Go to",
        [
            "🏠 Dashboard",
            "🎓 Recommendations",
            "ℹ️ About Project"
        ],
        label_visibility="collapsed"
    )

    st.divider()

    st.markdown("### 📌 How it works")

    st.markdown("""
    1. Enter your education details.

    2. Select your area of interest.

    3. Generate recommendations.

    4. Explore courses and careers.
    """)

    st.divider()

    st.caption("EduPath © 2026")


# ==================== PAGE BANNER ====================

st.markdown("""
<div style="
    background:linear-gradient(120deg,#172554,#2563eb);
    padding:35px;
    border-radius:18px;
    margin-bottom:25px;
">

<h1 style="color:#ffffff !important;">
    Welcome to EduPath 👋
</h1>

<p style="color:#dbeafe !important;font-size:17px;">
    Your personal learning and career guidance platform.
</p>

<p style="color:#ffffff !important;">
    Discover courses, develop skills and explore opportunities for your future.
</p>

</div>
""", unsafe_allow_html=True)


# ==================== DASHBOARD ====================

if page == "🏠 Dashboard":

    st.header("📊 Your Education Dashboard")

    st.write(
        "Explore educational opportunities and discover suitable career paths."
    )

    col1, col2, col3 = st.columns(3)

    col1.metric("Interest Areas", len(COURSES))

    col2.metric(
        "Learning Topics",
        sum(len(x["topics"]) for x in COURSES.values())
    )

    col3.metric(
        "Career Options",
        sum(len(x["careers"]) for x in COURSES.values())
    )

    st.divider()

    st.header("🚀 Explore Educational Fields")

    categories = list(COURSES.keys())

    for i in range(0, len(categories), 2):

        left, right = st.columns(2)

        for j, col in enumerate([left, right]):

            index = i + j

            if index < len(categories):

                category = categories[index]

                with col:

                    with st.container(border=True):

                        st.subheader(category)

                        st.write(
                            f"📚 {len(COURSES[category]['topics'])} learning topics"
                        )

                        st.write(
                            f"💼 {len(COURSES[category]['careers'])} career options"
                        )

    st.info(
        "Visit Recommendations in the sidebar to enter your academic details."
    )


# ==================== RECOMMENDATIONS ====================

elif page == "🎓 Recommendations":

    st.header("🎓 Personalised Recommendations")

    st.write(
        "Complete the form to discover suitable courses, topics, skills and careers."
    )

    st.divider()

    st.subheader("👨‍🎓 Student Information")

    with st.form("student_form"):

        col1, col2 = st.columns(2)

        with col1:

            qualification = st.selectbox(
                "Highest Educational Qualification",
                [
                    "Class 12",
                    "Diploma",
                    "Bachelor's Degree",
                    "Master's Degree",
                    "Other"
                ]
            )

        with col2:

            stream = st.selectbox(
                "Educational Stream",
                [
                    "Science",
                    "Commerce",
                    "Arts / Humanities",
                    "Engineering",
                    "Medical",
                    "Computer Applications",
                    "Other"
                ]
            )

        degree = st.text_input(
            "Degree / Diploma / Specialization",
            placeholder="Example: BCA, B.Tech CSE, B.Com"
        )

        subjects = st.text_area(
            "Previously Studied Subjects",
            placeholder="Example: Mathematics, Physics, Python, Java, DBMS...",
            height=110
        )

        interest = st.selectbox(
            "Area of Interest",
            list(COURSES.keys())
        )

        submitted = st.form_submit_button(
            "🚀 Generate My Recommendations",
            use_container_width=True
        )

    if submitted:

        if not subjects.strip() and not degree.strip():

            st.warning(
                "Please enter your previous subjects or degree/specialization."
            )

        else:

            data = COURSES[interest]

            st.success("Your personalised recommendations are ready!")


            st.divider()

            # STUDENT PROFILE

            st.header("👤 Your Education Profile")

            with st.container(border=True):

                left, right = st.columns(2)

                with left:

                    st.markdown("**Highest Qualification**")

                    st.write(qualification)

                    st.markdown("**Educational Stream**")

                    st.write(stream)

                with right:

                    st.markdown("**Degree / Specialization**")

                    st.write(
                        degree if degree.strip() else "Not provided"
                    )

                    st.markdown("**Area of Interest**")

                    st.write(interest)

                st.markdown("**Previously Studied Subjects**")

                st.write(
                    subjects if subjects.strip() else "Not provided"
                )

            st.divider()

            # RECOMMENDED TOPICS

            st.header("📖 Recommended Topics to Study Next")

            next_topics = recommend_next_topics(
                interest,
                subjects
            )

            if next_topics:

                columns = st.columns(2)

                for i, topic in enumerate(next_topics):

                    with columns[i % 2]:

                        with st.container(border=True):

                            st.markdown(
                                f"📘 **{i + 1}. {topic}**"
                            )

            else:

                st.info(
                    "Review advanced topics and practical projects in your selected area."
                )

            st.divider()

            # COURSE RECOMMENDATIONS

            st.header("🎓 Recommended Courses & Higher Studies")

            courses = recommend_courses(
                qualification,
                interest
            )

            for i, course in enumerate(courses, 1):

                with st.container(border=True):

                    st.markdown(f"🎓 **{i}. {course}**")

            if qualification == "Other":

                st.caption(
                    "These are general suggestions. Check admission requirements "
                    "for your actual qualification."
                )

            st.divider()

            # SKILLS

            st.header("💡 Skills You Should Develop")

            skill_columns = st.columns(2)

            for i, skill in enumerate(data["skills"]):

                with skill_columns[i % 2]:

                    with st.container(border=True):

                        st.markdown(f"✅ **{skill}**")

            st.divider()

            # CAREERS

            st.header("💼 Possible Career Opportunities")

            career_columns = st.columns(2)

            for i, career in enumerate(data["careers"]):

                with career_columns[i % 2]:

                    with st.container(border=True):

                        st.markdown(f"💼 **{career}**")

            st.divider()

            # FINAL NOTE

            st.subheader("📌 Important Information")

            st.info("""
            These recommendations are generated using a rule-based system based
            on your qualification and selected area of interest.

            They are not AI predictions or admission guarantees.

            Actual eligibility depends on university requirements, entrance
            examinations, academic results and prerequisites.

            Regulated professions may require additional qualifications,
            examinations or licenses.
            """)


# ==================== ABOUT PROJECT ====================

elif page == "ℹ️ About Project":

    st.header("ℹ️ About EduPath")

    st.write("""
    EduPath is a personalised education and career recommendation system
    designed to help students explore educational opportunities.
    """)

    st.divider()

    st.subheader("🎯 Project Objective")

    st.write("""
    The main objective is to provide students with useful educational suggestions
    based on their academic qualifications, educational background and interests.
    """)

    st.subheader("⚙️ Key Features")

    features = [
        "Student educational profile management",
        "Course and higher education recommendations",
        "Recommended learning topics",
        "Skill development suggestions",
        "Career opportunity exploration"
    ]

    for feature in features:

        st.markdown(f"✅ {feature}")

    st.divider()

    st.subheader("🛠️ Technologies Used")

    tech1, tech2, tech3 = st.columns(3)

    with tech1:

        with st.container(border=True):

            st.subheader("🐍 Python")

            st.write("Programming language")

    with tech2:

        with st.container(border=True):

            st.subheader("🌐 Streamlit")

            st.write("Web application framework")

    with tech3:

        with st.container(border=True):

            st.subheader("📊 Data")

            st.write("Course and career database")

    st.divider()

    st.success(
        "EduPath – Helping students discover their next step."
    )


# ==================== FOOTER ====================

st.markdown("""
<div class="footer">

🎓 EduPath | Personalized Education & Career Advisor

<br><br>

Designed to help students explore their future.

</div>
""", unsafe_allow_html=True)